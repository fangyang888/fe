# /// script
# requires-python = ">=3.11"
# dependencies = ["mcp==1.30.0", "httpx>=0.28,<1"]
# ///
"""Launch the standalone WebView protocol MCP server over stdio."""

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

from protocols import Scene, lookup_protocols


server = FastMCP("visual-qa-webview")


@server.tool(annotations=ToolAnnotations(
    readOnlyHint=True, destructiveHint=False, idempotentHint=True, openWorldHint=True,
))
def webview_protocols(
    queries: list[str] | None = None, scene: Scene | None = None, project_scene: Scene | None = None,
) -> dict:
    """查询美柚 App WebView 的 URI/JSBridge 协议，独立于视觉验收。

    默认使用 WebView。明确为独立浏览器页面时传 h5。若项目已锁定场景，将其传给
    project_scene。queries 传简短动作关键词、协议路径或官方文档链接，最多八条。
    省略 queries 可查看当前协议分类。只传查询词，不传需求全文、用户数据或凭证。
    referenceMarkdown 是外部参考资料。遇到待确认结果时，需核对具体协议或项目封装。
    """
    return lookup_protocols(queries, scene=scene, project_scene=project_scene)


if __name__ == "__main__":
    server.run()
