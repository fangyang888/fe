"""Resolve the runtime scene and look up Meiyou URI documentation."""

from __future__ import annotations

import re
from typing import Literal

import httpx


Scene = Literal["webview", "h5"]
DOCS_URL = "https://apidoc.seeyouyima.com/uri-docs/#/docs/"
API_URL = "https://apidoc.seeyouyima.com/uri-docs-api/"
DOC_ID = re.compile(r"[0-9a-f]{24}", re.IGNORECASE)
PATH_FIELD = re.compile(r"^[ \t]*(?:-[ \t]+)?\**(?:路径|path)\**[ \t]*[:：]\**[ \t]*(.+)$", re.I | re.M)
METHOD_FIELD = re.compile(r"^[ \t]*\**调用方式\**[ \t]*[:：]\**[ \t]*(.+)$", re.M)
SDK_METHOD = re.compile(r"\b(?:callNative|on|off)\b")
PROTOCOL_PATH = re.compile(r"/?[\w.-]+(?:/[\w.-]+)*", re.ASCII)
ALIASES = {
    "打开网页": "web",
    "跳转网页": "web",
    "打开新网页": "web",
    "打开新webview": "web",
    "全屏打开网页": "web/pure",
    "全屏webview": "web/pure",
    "app登录": "登录",
    "唤起登录": "登录",
    "唤起app登录": "登录",
    "login": "登录",
    "分享": "分享功能",
    "app分享": "分享功能",
    "监听网络变化": "网络变化事件",
}
MAX_CANDIDATES = 5
MAX_MARKDOWN = 6_000


class DocsUnavailable(Exception):
    """The official read-only endpoint could not provide a usable response."""


def _read(client: httpx.Client, endpoint: str, **params):
    try:
        response = client.get(endpoint, params=params)
        response.raise_for_status()
        payload = response.json()
    except (httpx.HTTPError, ValueError) as exc:
        raise DocsUnavailable("无法访问美柚 Uri-Docs，请检查网络或稍后重试。") from exc
    if not isinstance(payload, dict) or payload.get("success") is not True or "data" not in payload:
        raise DocsUnavailable("美柚 Uri-Docs 返回了无效响应。")
    return payload["data"]


def _collection(value) -> list:
    if not isinstance(value, list):
        raise DocsUnavailable("美柚 Uri-Docs 的目录或搜索响应格式已变化。")
    return value


def _current(category: dict) -> bool:
    # Uri-Docs labels categories created before 2023 as deprecated.
    meta = category.get("meta")
    created_at = meta.get("createdAt") if isinstance(meta, dict) else None
    return isinstance(created_at, str) and created_at[:4].isdigit() and created_at[:4] >= "2023"


def _reference(doc_id: str, name: str, category: str) -> dict:
    return {"docId": doc_id, "name": name, "category": category, "url": DOCS_URL + doc_id}


def _contract(markdown: str) -> tuple[str | None, list[str]]:
    field = PATH_FIELD.search(markdown)
    path = field[1].strip().strip("`").strip() if field else ""
    if not PROTOCOL_PATH.fullmatch(path) or path.casefold().lstrip("/") in {"path", "your/path", "xxx", "..."}:
        return None, []
    field = METHOD_FIELD.search(markdown)
    methods = list(dict.fromkeys(SDK_METHOD.findall(field[1]))) if field else []
    return path, methods


def _detail(client: httpx.Client, doc_id: str, categories: dict) -> dict:
    data = _read(client, "get-uri", docId=doc_id)
    if data is None or (isinstance(data, dict) and data.get("isDeleted")):
        return {"status": "not_found"}
    if not isinstance(data, dict) or data.get("_id") != doc_id or not isinstance(data.get("name"), str):
        raise DocsUnavailable("美柚 Uri-Docs 的详情响应格式已变化。")
    category = categories.get(data.get("category"), {})
    reference = _reference(doc_id, data["name"], category.get("name", ""))
    markdown = data.get("mdContent") or ""
    if not isinstance(markdown, str):
        raise DocsUnavailable("美柚 Uri-Docs 的详情响应格式已变化。")
    reference["referenceMarkdown"] = markdown[:MAX_MARKDOWN]
    reference["referenceTruncated"] = len(markdown) > MAX_MARKDOWN
    if not _current(category):
        return {"status": "needs_confirmation", "reason": "deprecated_or_unclassified", "document": reference}
    path, methods = _contract(markdown)
    if path is None or not methods:
        return {"status": "needs_confirmation", "reason": "incomplete_contract", "document": reference}
    return {"status": "matched", "path": path, "methods": methods, "document": reference}


def _lookup(client: httpx.Client, query: str, categories: dict, entries: list[dict]) -> dict:
    reference = query.removeprefix(DOCS_URL).lower()
    if DOC_ID.fullmatch(reference):
        return _detail(client, reference, categories)

    term = ALIASES.get("".join(query.casefold().split()), query)
    key = term.casefold()
    exact = [entry for entry in entries if entry["name"].casefold() == key]
    if len(exact) == 1:
        return _detail(client, exact[0]["docId"], categories)
    if exact:
        return {"status": "needs_confirmation", "reason": "ambiguous", "candidates": exact[:MAX_CANDIDATES]}

    category_matches = [entry for entry in entries if entry["category"].casefold() == key]
    if category_matches:
        return {"status": "needs_confirmation", "reason": "review_candidates",
                "candidates": category_matches[:MAX_CANDIDATES]}

    # The upstream search interprets regex metacharacters.
    matches = _collection(_read(client, "search-uri", keyword=re.escape(term)))
    active = {entry["docId"]: entry for entry in entries}
    same_path = {}
    candidates = {}
    for hit in matches:
        reference = active.get(hit.get("_id")) if isinstance(hit, dict) else None
        if not reference:
            continue
        candidates[reference["docId"]] = reference
        markdown = hit.get("mdContent")
        if isinstance(markdown, str):
            path, _ = _contract(markdown)
            if path and path.casefold() == key:
                same_path[reference["docId"]] = reference
    if len(same_path) == 1:
        return _detail(client, next(iter(same_path)), categories)
    candidates = same_path or candidates
    if candidates:
        return {"status": "needs_confirmation", "reason": "ambiguous" if same_path else "review_candidates",
                "candidates": list(candidates.values())[:MAX_CANDIDATES]}
    return {"status": "not_found"}


def lookup_protocols(
    queries: list[str] | None = None, *, scene: Scene | None = None, project_scene: Scene | None = None,
) -> dict:
    """Look up short action labels, protocol paths or Uri-Docs links in one scene."""
    if any(value not in (None, "webview", "h5") for value in (scene, project_scene)):
        raise ValueError("scene and project_scene must be webview or h5")
    if scene and project_scene and scene != project_scene:
        raise ValueError("scene conflicts with project_scene")
    runtime = scene or project_scene or "webview"
    result = {
        "scene": runtime,
        "sceneSource": "explicit" if scene else "project" if project_scene else "default",
        "h5Fallback": False,
        "status": "ready",
        "results": [],
    }
    if runtime == "h5":
        return result

    terms = [query.strip() for query in queries or []]
    if len(terms) > 8 or any(not term or len(term) > 100 or "\n" in term or "\r" in term for term in terms):
        raise ValueError("Provide at most eight single-line lookup terms, each 1–100 characters")
    if any("://" in term and not DOC_ID.fullmatch(term.removeprefix(DOCS_URL)) for term in terms):
        raise ValueError("Use a canonical Meiyou Uri-Docs link or a short lookup term")
    terms = list(dict.fromkeys(terms))

    with httpx.Client(base_url=API_URL, timeout=5.0) as client:
        try:
            categories = {
                category["_id"]: category
                for category in _collection(_read(client, "get-categories"))
                if isinstance(category, dict) and isinstance(category.get("_id"), str)
                and isinstance(category.get("name"), str) and not category.get("isDeleted")
            }
            current = [category for category in categories.values() if _current(category)]
            entries = [
                _reference(entry["id"], entry["name"], category["name"])
                for category in current for entry in _collection(category.get("uri"))
                if isinstance(entry, dict) and DOC_ID.fullmatch(str(entry.get("id", "")))
                and isinstance(entry.get("name"), str)
            ]
        except DocsUnavailable as exc:
            return {**result, "status": "unavailable", "error": str(exc)}
        if not terms:
            counts = {category["name"]: len(category["uri"]) for category in current}
            return {**result, "categories": [{"name": name, "count": count} for name, count in counts.items()]}

        for term in terms:
            try:
                match = _lookup(client, term, categories, entries)
            except DocsUnavailable as exc:
                match = {"status": "unavailable", "error": str(exc)}
            result["results"].append({"query": term, **match})
    outcomes = {match["status"] for match in result["results"]}
    if outcomes == {"unavailable"}:
        result["status"] = "unavailable"
    elif outcomes != {"matched"}:
        result["status"] = "needs_confirmation"
    return result
